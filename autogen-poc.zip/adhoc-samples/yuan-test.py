#! pip3 install pyautogen

import os

from openai import AzureOpenAI

api_version='2024-02-01'

def get_chatcompletion_response(prompt: str, model: str='gpt-4-128k-0125'):

     return ""



def create_client_profile_yw(path:str):
    return {
        "students": [
            {"name": "John Doe"},
            {"name": "Jane Smith"}
        ]
    }

import autogen

from typing import Literal



from pydantic import BaseModel, Field

from typing_extensions import Annotated



import autogen

from autogen.cache import Cache





config_list_gpt4 = autogen.config_list_from_json(env_or_file="AOAI_CONFIG_LIST")

#print(config_list_gpt4)



gpt4_config = {
     "cache_seed": 42,
     "temperature": 0,
     "config_list": config_list_gpt4,
     "timeout": 120,
}

chatbot = autogen.AssistantAgent(
     name="chatbot",
     system_message="""Chatbot.
     Create client profiles based on provided financial statement and provide results to the inner_proxy and user_proxy agent for review. 
     For creating client profile tasks, only use the functions you have been provided with. Do not await confirmation on the suggested tools to be called but instead call the tools
     and return the results immediately.
     Confirm the results with user_proxy and adjust the results based on feedback from user_proxy as needed.""",
     llm_config=gpt4_config,

    human_input_mode="NEVER",
)

inner_proxy = autogen.UserProxyAgent(
        name="inner_proxy",
        system_message="""inner_proxy. Interact with the chatbot to discuss the result. Confirm with user_proxy the result look good.
        ask user_proxy for changes and have chatbot update the result. if user_proxy is satisfied with the result, print out the result.
        """,
        human_input_mode="NEVER",
        max_consecutive_auto_reply=10,
    )

chatbot.register_nested_chats(
    trigger="inner_proxy",
    max_round=50,
    chat_queue={
            # The initial message is the one received by the player agent from
            # the other player agent.
            "sender": inner_proxy,
            "recipient": chatbot,
            # The final message is sent to the player agent.
            "summary_method": "last_msg",
        }
)

# create a UserProxyAgent instance named "user_proxy"
user_proxy = autogen.UserProxyAgent(
     name="user_proxy",
     system_message="""A human admin. Request the chatbot to create client profiles based on provided financial statement. 
     You must give the final decision on the generated client profiles.""",
     is_termination_msg=lambda x: x.get("content", "") and x.get("content", "").rstrip().endswith("TERMINATE"),
     #human_input_mode="NEVER",
     max_consecutive_auto_reply=10,
)
critic = autogen.AssistantAgent(
    name="Critic",
    system_message="""Critic. Double the returned client profile from the inner_proxy agent with the user_proxy agent. 
    Based on feedback ask the inner_proxy agent to make the necessary adjustments and return the modified client profile. 
    Reconfirm the new results with user_proxy until user_proxy confirms the result is satisfactory.
    Once user_proxy confirms the result is satisfactory, print out the final result and TERMINATE the chat by sending a message with the word TERMINATE.""",
    llm_config=gpt4_config,
)

@inner_proxy.register_for_execution()
@chatbot.register_for_llm(description="""This function takes in a
financial statement and create client profile for this financial statement.""")
def create_client_profile_agent(path:str):
    return {
        "students": [
            {"name": "John Doe"},
            {"name": "Jane Smith"}
        ]
    }
  

groupchat = autogen.GroupChat(
     agents=[user_proxy, chatbot, critic, inner_proxy], messages=[], max_round=50 #user_proxy2], messages=[], max_round=50
)

manager = autogen.GroupChatManager(groupchat=groupchat, llm_config=gpt4_config)

# Start the chat
user_proxy.initiate_chat(
     manager,
     message="""
please create a client profile for FY21-RedCross-Audited-Financial-Statement.pdf
""",
)

'''
with Cache.disk() as cache:
# start the conversation
     res = user_proxy.initiate_chat(
          chatbot, message="please create a client profile for FY21-RedCross-Audited-Financial-Statement.pdf", summary_method="reflection_with_llm", cache=cache
     )
'''