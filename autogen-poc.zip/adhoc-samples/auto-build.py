import autogen
from autogen.agentchat.contrib.agent_builder import AgentBuilder

## Defining globals
config_list = autogen.config_list_from_json(
                    env_or_file="AOAI_CONFIG_LIST",
                    file_location=".",
                    filter_dict={
                        "model": {"gpt-4-deployment"}
                    },
                )

default_llm_config = {
    "cache_seed": 42,  # change the cache_seed for different trials
    "temperature": 0,
    "config_list": config_list,
    "timeout": 120,
}

def start_task(execution_task: str, agent_list: list[autogen.ConversableAgent], llm_config: dict):
    group_chat = autogen.GroupChat(agents=agent_list, messages=[], max_round=12)
    manager = autogen.GroupChatManager(
        groupchat=group_chat, llm_config={"config_list": config_list, **llm_config}
    )
    agent_list[0].initiate_chat(manager, message=execution_task)


builder = AgentBuilder(config_file_or_env="./AOAI_CONFIG_LIST", builder_model="gpt-4-deployment", agent_model="gpt-4-deployment")

building_task = "Find a paper on arxiv by programming and analyze its application in some domain. For example, find a latest paper about gpt-4 on arxiv and find its potential applications in software"

agent_list, agent_configs = builder.build(building_task=building_task, default_llm_config=default_llm_config, coding=True)

start_task(
    execution_task=building_task, 
    agent_list=agent_list, 
    llm_config=default_llm_config
)

